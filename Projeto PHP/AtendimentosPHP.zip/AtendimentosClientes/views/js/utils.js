function index(){
	window.location.href = 'index.php';
}