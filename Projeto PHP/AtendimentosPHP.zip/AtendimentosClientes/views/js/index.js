var id = "";
var cliente = "";
$(document).ready(function() {
	$('.linha-table').click(function() {
		$('.linha-table').removeClass('checked');
		$(this).addClass('checked');
		id = $(this.children[0]).text();
		cliente = $(this.children[1]).text();
	});
});

function excluirCliente() {
	if (id == "") {
		alert('Favor selecionar um atendimento para excluir.');
	} else {
		var boxConfirmar = confirm("Deseja excluir o atendimento do " + id + "-"
				+ cliente + "?");
		if (boxConfirmar == true) {
			window.location.href='../controllers/ExcluirAtendimentoController.php?id=' + id;
		} else {

		}
	}
}