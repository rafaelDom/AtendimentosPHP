<?php
require_once '../models/Atendimento.php';
require_once 'ConexaoSQL.php';

class RepositorioAtendimento
{

    private $conexao;

    public function __construct()
    {
        $this->conexao = Conexao::getConnection();
    }

    public function salvar(Atendimento $atendimento)
    {
        $cliente = $atendimento->getCliente();
        $cpf = $atendimento->getCpf();
        $dataAtendimento = $atendimento->getDataAtendimento();
        $motivo = $atendimento->getMotivo();
        $solucao = $atendimento->getSolucao();

        $sqlGravar = "INSERT INTO atendimento (cliente, cpf, dataAtendimento, motivo, solucao) VALUES(
    																'$cliente',
    																'$cpf',
    																'$dataAtendimento',
    																'$motivo',
    																'$solucao'
    												)
    								";
        $this->conexao->query($sqlGravar);
    }

    public function listAll()
    {
        $sqlBuscar = "select top 10 *from atendimento order by id desc";

        $resultado = $this->conexao->query($sqlBuscar);

        $atendimentos = [];

        while ($atendimento = $resultado->fetch()) {
            $atendimentos[] = $atendimento;
        }
        return $atendimentos;
    }

    public function excluir($id)
    {
        $sqlDeletar = "delete from atendimento where id = $id";

        $this->conexao->query($sqlDeletar);
    }
}